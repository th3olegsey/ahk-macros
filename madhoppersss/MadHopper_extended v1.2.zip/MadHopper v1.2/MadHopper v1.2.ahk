#Requires AutoHotkey v2.0
#Include libs\Jxon.ahk
PLACE_ID := 1224212277
api := "https://games.roblox.com/v1/games/" PLACE_ID "/servers/Public?limit=100"
http := ComObject("WinHttp.WinHttpRequest.5.1")
privateservers := Map()
currentServer := ""
; - - - = = = # # # M A I N   G U I # # # = = = - - -
madHopperGui := Gui("AlwaysOnTop", "MadHopperV1.2")
madHopperGuiTabs := madHopperGui.AddTab3(,["Main", "Private servers", 'Exposed values'])
serversOnlineText := madHopperGui.Add("text","w100" ,"Servers online: -")
serversOnlineText.GetPos(&X, &Y, &W, &H)
lastJoinedServer := madHopperGui.Add("text", "Y" Y+H " X" X " w150", "Current server: -")
LV := madHopperGui.Add("ListView", "r4 w157", ["Long id", "№", "Server", "Playing"])
LV.ModifyCol(1, 0)
LVPos := LV.GetPos(&X, &Y, &W, &H)
updateServersBtn := madHopperGui.AddButton("X" X+W " Y" Y-2 " W80" ,"Update")
updateServersBtn.GetPos(&X, &Y, &W, &H)
inviteBtn := madHopperGui.AddButton("X" X " Y" Y+H " W" W, "Copy JobID")
inviteBtn.GetPos(&X, &Y, &W, &H)
rejoinbtn := madHopperGui.AddButton("X" X " Y" Y+H " W" W, "Rejoin")
rejoinBtn.GetPos(&X, &Y, &W, &H)
helpBtn := madHopperGui.AddButton("X" X " Y" Y+H " W" W, "Help")

madHopperGuiTabs.UseTab(2)
LVPs := madHopperGui.Add("ListView", "r5 w157", ["Link code", "Name", "Desc",])
LVPs.GetPos(&X, &Y, &W, &H)
LVPs.ModifyCol(1, 0)
addPsBtn := madHopperGui.AddButton("X" X+W " Y" Y-2 " W80" ,"Add server")
addPsBtn.GetPos(&X, &Y, &W, &H)
removeServerbtn := madHopperGui.AddButton("X" X " Y" Y+H " W" W,"Remove server")

madHopperGuiTabs.UseTab(3)
placeid := madHopperGui.Add('Text',,'PLACE_ID :=')
placeid.GetPos(&X, &Y, &W, &H)
placeid_edit := madHopperGui.Add('Edit','X' X+W+6 ' Y' Y, 1224212277)


PSfile := FileOpen("PrivateServers.json", "rw")
privateservers_json := PSfile.Read()
if(!privateservers_json){
    PSfile.Write("{`"data`":[]}")
    PSfile.Close
    PSfile := FileOpen("PrivateServers.json", "rw")
    privateservers_json := PSfile.Read()
}
privateservers := Jxon_Load(&privateservers_json)
global_pservers := privateservers["data"]
if(global_pservers.Capacity >= 1){
    for ps in global_pservers{
        LVPs.Add(, ps["linkCode"], ps["name"], ps["description"])
    }
}
LVPs.ModifyCol()
LVPs.ModifyCol(1, 0)
PSfile.Close

LV.OnEvent("DoubleClick", LV_DoubleClick)
LV.OnEvent("Click", quickJoin)
updateServersBtn.OnEvent("Click", updateServers)
inviteBtn.OnEvent("Click", copyJobId)
rejoinbtn.OnEvent("Click", rejoin)
helpBtn.OnEvent("Click", callhelp)
addPsBtn.OnEvent("Click", callAddPS)
LVPs.OnEvent("DoubleClick", LVPs_DoubleClick)
removeServerbtn.OnEvent("Click", removeContentFromLVPs)
placeid_edit.OnEvent('Change', updateValues)


madHopperGui.Show()
WinSetTransparent(100, "MadHopper")
; - - - = = = # # # A D D   P R I V A T E   S E R V E R   G U I # # # = = = - - -
addPsGui := Gui(,"Add Private server")
linkcodetxt := addPsGui.AddText(,"Link code: ")
linkcodetxt.GetPos(&X1, &Y1, &W1, &H1)
psNametxt := addPsGui.AddText("X" X1 " Y" Y1+H1+5,"Name of the private server: ")
psNametxt.GetPos(&X, &Y, &W, &H)
psDesctxt := addPsGui.AddText("X" X " Y" Y+H+5, "Description of the server: ")
psDesctxt.GetPos(&X, &Y, &W2, &H)
addpsBtn2 := addPsGui.AddButton("X" X " Y" Y+H+5, "Add!")
linkcodeEdit := addPsGui.AddEdit("X" X1+W2+15 " Y" Y1-4)
linkcodeEdit.GetPos(&X, &Y, &W, &H)
psNameEdit := addPsGui.AddEdit("X" X " Y" Y+H)
psNameEdit.GetPos(&X, &Y, &W, &H)
psDescEdit := addPsGui.AddEdit("X" X " Y" Y+H)

addpsBtn2.OnEvent("Click", addPS)

updateValues(*){
    global PLACE_ID := placeid_edit.Value
    global api := "https://games.roblox.com/v1/games/" PLACE_ID "/servers/Public?limit=100"
}
LV_DoubleClick(LV, RowNumber){
    RowText := LV.GetText(RowNumber)
    global currentServer := RowText
    Run("roblox://placeId=" PLACE_ID "&gameInstanceId=" RowText)
    curSer := StrSplit(RowText, "-")
    lastJoinedServer.Text := "Current server: " curSer[2] "-" curSer[3]
}
updateServers(*){
    http.Open("GET", api, false)
    http.Send()
    apiresponse := http.ResponseText
    root := Jxon_Load(&apiresponse)
    if(root.Has("errors")){
        apiErrors := root["errors"]
        return MsgBox("Error: " apiErrors[1]['message'], "API Error")
    }
    global servers := root["data"]
    global serversOnline := servers.Length
    serversOnlineText.Text := "Servers online: " serversonline
    if(LV.GetCount != 0){
        LV.Delete()
    }
    servercount := 1
    for s in servers{
        TS := StrSplit(s["id"], "-")
        LV.Add(, s["id"], servercount, TS[2] "-" TS[3], s["playing"] "/" s["maxPlayers"])
        servercount += 1
    }
    LV.ModifyCol(1, 0)
    LV.ModifyCol(2)
    LV.ModifyCol(3)
    LV.ModifyCol(4, 47)
}
copyJobId(*){
    if(currentServer){
        A_Clipboard := currentServer
    }
}
quickJoin(LV, RowNumber){
    if(GetKeyState("Alt")){
        RowText := LV.GetText(RowNumber)
        global currentServer := RowText
        Run("roblox://placeId=" PLACE_ID "&gameInstanceId=" RowText)
        curSer := StrSplit(RowText, "-")
        lastJoinedServer.Text := "Current server: " curSer[2] "-" curSer[3]
    }
}
callhelp(*){
    MsgBox("List controls:`nDouble click - join to the server`nAlt+click - quickly join to the server`n`nButtons:`nUpdate - updates the server list`nCopy JobID - copies server ID from 'current server' param`nHelp - calls this gui", "Help")
}
callAddPS(*){
    if(linkcodeEdit.Value){
        linkcodeEdit.Value := ""
    }
    if(psNameEdit.Value){
        psNameEdit.Value := ""
    }
    if(psDescEdit.Value){
        psDescEdit.Value := ""
    }
    addPsGui.Show()
}
addPS(*){
    PSfile := FileOpen("PrivateServers.json", "rw")
    if(linkcodeEdit.Value == ""){
        return MsgBox("Please, enter a valid link code")
    }
    if(psNameEdit.Value == ""){
        return MsgBox("Please, give the server a name")
    }

    json := PSfile.Read()
    root := Jxon_Load(&json)
    Pservers := root["data"]
    Pservers.Push(Map("linkCode", linkcodeEdit.Value, "name", psNameEdit.Value, "description", psDescEdit.Value))
    json := Jxon_Dump(root)

    FileDelete("PrivateServers.json")
    PSfile := FileOpen("PrivateServers.json", "rw")
    PSfile.Write(json)
    PSfile.Close()

    if(LVPs.GetCount != 0){
        LVPs.Delete()
    }
    for ps in Pservers{
            LVPs.Add(, ps["linkCode"], ps["name"], ps["description"])
        }
        LVPs.ModifyCol
        LVPs.ModifyCol(1, 0)
    WinClose("Add Private server")
}
LVPs_DoubleClick(LV, RowNumber){
    RowText := LV.GetText(RowNumber)
    global currentServer := RowText
    Run("roblox://placeId=" PLACE_ID "&linkCode=" RowText)
}
removeContentFromLVPs(*){
    json := FileRead("privateservers.json", "UTF-8")
    root := Jxon_Load(&json)
    Pservers := root["data"]
    selectedPserver := LVPs.GetNext()
    Pservers.RemoveAt(selectedPserver)
    json := Jxon_Dump(root)
    FileDelete("PrivateServers.json")
    PSfile := FileOpen("privateservers.json", "rw")
    PSfile.Write(json)
    PSfile.Close()
    if(LVPs.GetCount != 0){
        LVPs.Delete()
    }
    for ps in Pservers{
        LVPs.Add(, ps["linkCode"], ps["name"], ps["description"])
    }
    LVPs.ModifyCol
    LVPs.ModifyCol(1, 0)
}
rejoin(*){
    Run("roblox://placeId=" PLACE_ID "&gameInstanceId=" currentServer)
}
updateServers